#!/bin/ksh
cd /opt/c430/000/instala_16246568
rm Usr8.tar

cd /opt/c430/000/bin/s702
tar -cvf Usr8.tar *
mv Usr8.tar /opt/c430/000/instala_16246568
