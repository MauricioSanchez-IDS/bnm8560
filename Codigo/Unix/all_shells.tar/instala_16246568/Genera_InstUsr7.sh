#!/bin/ksh
cd /opt/c430/000/instala_16246568
rm Usr7.tar

cd /opt/c430/000/bin/s111
tar -cvf Usr7.tar recepcion/*
mv Usr7.tar /opt/c430/000/instala_16246568


