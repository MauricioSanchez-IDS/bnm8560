cc -V   C430RepCred.o ./reportes2/lib_rep.o rep13.o  rep14.o rep16.o  rep18.o  rep20.o  rep22.o  rep24.o  rep26.o  /opt/sybase125/OCS-12_5/lib/libsybdb.sl /opt/c046/105/lib/libagenteSapufHpux.sl /opt/c046/105/lib/libdes32sapuf.sl -lm -o Cliente

