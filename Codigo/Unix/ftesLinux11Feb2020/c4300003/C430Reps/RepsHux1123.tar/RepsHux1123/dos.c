#include <stdio.h>

main()
{
int a;

a=0;

do
{
a=a+1;
switch (a)
{
case 1: 
       printf("numero %d\n",a);
       break;
case 2:
       printf("numero %d\n",a);
       break;
case 3:
       printf("numero %d\n",a);
       break;
case 4:
       printf("numero %d\n",a);
       break;
case 5:
       printf("numero %d\n",a);
       break;
case 6:
       printf("numero %d\n",a);
       break;
case 7:
       printf("numero %d\n",a);
       break;
case 8:
       printf("numero %d\n",a);
       break;
case 9:
       printf("numero %d\n",a);
       break;
case 10:
       printf("numero %d\n",a);
       break;
} /*fin switch */
}while (a < 10);

}
