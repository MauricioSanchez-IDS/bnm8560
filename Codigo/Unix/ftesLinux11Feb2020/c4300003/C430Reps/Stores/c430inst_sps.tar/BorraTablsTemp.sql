use M111
go

drop table MTCMES01
go

drop table CARATD01
go

drop table CARHEA01
go

drop table CARPLS01
go

drop table CARHST01
go

drop table CARTAR01
go

drop table CARMAP01
go


