#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<math.h>
#include	<unistd.h>
#include        "SAPUF_Enlace.h"

#include	<sybfront.h>
#include	<sybdb.h>

#define		WARNING		1
#define		SUCCESS		0
#define		FAILURE		-1


#ifndef		__CONEXION_H
#include	<conexion.h>
#endif

#ifndef		__VARREP_H
#include	<varrep.h>
#endif

#ifndef		__VOLCAD_H
#include	<volcad.h>
#endif

#ifndef		__RISQLDB_H
#include	<risqldb.h>
#endif

#ifndef		__ARBOLUNI_H
#include	<arboluni.h>
#endif

#ifndef		__FORMATEO_H
#include	<formateo.h>
#endif

void init()
{
}
