﻿using System.Runtime.InteropServices;

namespace EvaluadorExpReg
{
    [CoClass(typeof(clsExpresionesRegularesClass))]
    [Guid("77F26AC0-1F64-42D3-8A0B-69AFBE82BD88")]
    public interface clsExpresionesRegulares : _clsExpresionesRegulares
    {
    }
}
